package com.wordoftheday.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class WordOfDayWidget extends AppWidgetProvider {

    private static final String ACTION_REFRESH = "com.wordoftheday.widget.REFRESH";

    private static final int[] IMAGES = {
        R.drawable.frog_001, R.drawable.frog_002, R.drawable.frog_003, R.drawable.frog_004,
        R.drawable.frog_005, R.drawable.frog_006, R.drawable.frog_007, R.drawable.frog_008,
        R.drawable.frog_009, R.drawable.frog_010, R.drawable.frog_011, R.drawable.frog_012,
        R.drawable.frog_013, R.drawable.frog_014, R.drawable.frog_015, R.drawable.frog_016,
        R.drawable.frog_017, R.drawable.frog_018, R.drawable.frog_019, R.drawable.frog_020,
        R.drawable.frog_021, R.drawable.frog_022, R.drawable.frog_023, R.drawable.frog_024,
        R.drawable.frog_025, R.drawable.frog_026, R.drawable.frog_027, R.drawable.frog_028,
        R.drawable.frog_029, R.drawable.frog_030, R.drawable.frog_031, R.drawable.frog_032,
        R.drawable.frog_033, R.drawable.frog_034, R.drawable.frog_035, R.drawable.frog_036,
        R.drawable.frog_037, R.drawable.frog_038, R.drawable.frog_039, R.drawable.frog_040,
        R.drawable.frog_041, R.drawable.frog_042, R.drawable.frog_043, R.drawable.frog_044,
        R.drawable.frog_045, R.drawable.frog_046, R.drawable.frog_047, R.drawable.frog_048,
        R.drawable.frog_049, R.drawable.frog_050, R.drawable.frog_051, R.drawable.frog_052,
        R.drawable.frog_053, R.drawable.frog_054, R.drawable.frog_055, R.drawable.frog_056,
        R.drawable.frog_057, R.drawable.frog_058, R.drawable.frog_059
    };

    private static final String[] MESSAGES = {
        "kuu kiurusta kesään ja 3,50 kaljasta",
        "And the Lord saw the potato and said, “This will do,” as he waddled back to the toilet.",
        "ootko makkara ku haluisin puristaa sinappia siu päälle",
        "If you put your wallet next to your ear, you can almost hear the juice.",
        "tårtå på tårtå.",
        "Jesus forgot the groceries, so you can fuck up too.",
        "And god created beer, cause reeb wouldn't make any sense.",
        "lapa jäähän ja nimi lehteen (alibiin)",
        "oot söpö t. kikki hiiri",
        "Today, you should probably bring a shovel to the fight. To fight what? The magic midget will show you.",
        "Miracles do happen, as Jokerit won a game.",
        "jo on leikki leiväst ja tuska tupakast.",
        "And on the seventh day Jesus came back from the dead and said, “Mayonnaise.”",
        "Today's message from our lord and saviour says: trust the fart. It might surprise you. Maybe not in a good way. But it will surprise you.",
        "Today is a good day to use a croissant. For what? That's up to you to decide.",
        "ellemme varmuudella tiedä, kuinka tulee käymään, olettakaamme, että kaikki käy hyvin. saatana.",
        "And God looked upon the mess and realized who was responsible. It was the juice.",
        "Today you might feel a tingle in your butt. Don't mind it. It's just my finger.",
        "nälkä siirtyy, ei lähde.",
        "Röpöttää röpöttää mutta ei voi mitään.",
        "Sano mummo ku pikkusen liukastu.",
        "Kyllä mä laitan juuston ensin kun leivän",
        "Jos en olis heränny olisin vieläki nukkumassa",
        "Kuvaile itseäsi yhdellä sanalla: reipas",
        "he protecc, but he also attacc",
        "“You’re gonna need a bigger boat.”",
        "“I love the smell of napalm in the morning.”",
        "“We’re not in Kansas anymore.”",
        "“There’s no place like home.”",
        "“I’m exercising the right not to walk.”",
        "“Forget it, Jake. It’s Chinatown.”",
        "“Can you fly, Bobby?”",
        "“There’s children throwing snowballs instead of throwing heads.”",
        "“Although Kazakhstan a glorious country, it have a problem too: economic social and jew.”",
        "“Is this a cat in a hat?”",
        "“Even though my anus was broken, I knew the rest of our journey would be great success.”",
        "“U.S. dollars and a jar of gypsy tears to protect me from AIDS.”"
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateWidget(context, manager, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, WordOfDayWidget.class));
            for (int id : ids) updateWidget(context, manager, id);
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager,
                                          int appWidgetId, Bundle newOptions) {
        updateWidget(context, appWidgetManager, appWidgetId);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        Calendar cal = Calendar.getInstance();
        long seed = (cal.get(Calendar.YEAR) * 1000L) + cal.get(Calendar.DAY_OF_YEAR);

        int imageIndex = new Random(seed * 1103515245L + 12345L).nextInt(IMAGES.length);
        int messageIndex = new Random(seed * 214013L + 2531011L).nextInt(MESSAGES.length);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_word_of_day);
        views.setImageViewResource(R.id.widget_image, IMAGES[imageIndex]);
        views.setTextViewText(R.id.widget_text, MESSAGES[messageIndex]);

        Intent refresh = new Intent(context, WordOfDayWidget.class);
        refresh.setAction(ACTION_REFRESH);
        PendingIntent pending = PendingIntent.getBroadcast(
                context, appWidgetId, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_image, pending);
        views.setOnClickPendingIntent(R.id.widget_text, pending);
        views.setOnClickPendingIntent(R.id.widget_title, pending);

        manager.updateAppWidget(appWidgetId, views);
    }
}
