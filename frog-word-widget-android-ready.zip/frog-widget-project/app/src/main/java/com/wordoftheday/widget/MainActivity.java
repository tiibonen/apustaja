package com.wordoftheday.widget;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView view = new TextView(this);
        view.setText("Word of the Day\n\nAdd the widget to your home screen.\nThe frog and message change daily.");
        view.setTextSize(18);
        view.setPadding(48, 48, 48, 48);
        setContentView(view);
    }
}
