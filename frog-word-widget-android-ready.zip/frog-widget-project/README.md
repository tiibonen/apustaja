# Word of the Day Android Widget

A standalone home-screen widget with a daily random frog image and one message from the built-in text pack.

## Behavior
- 59 bundled frog images.
- One deterministic random image per calendar day.
- One deterministic random message per calendar day.
- The same image/message remains for the whole day.
- Tapping the widget refreshes it, but because the selection is date-based it still stays on that day's image/message.
- The widget also listens for date/time/time-zone changes and requests regular system updates.

## Build
GitHub Actions builds the debug APK with Gradle 8.10.2 and Java 17.
